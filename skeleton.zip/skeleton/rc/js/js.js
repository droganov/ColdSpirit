var j = jQuery.noConflict();

j(function(){
	
});